import serial
import time

# Replace with the correct port and baudrate
port = 'COM8'
baudrate = 112500  # Adjust this to match your device's settings




# The two bytes to be sent
# follow left-hand lane"0xE8,0x17" follow right-hand lane: "0xE4,0x1B", Straight aheat: "0xEC,0x13", No lane is selected error code5: "0xE0, 0x1F"
# request Telegram: "0xC8,0x37"
# byte1 = "C8"
# byte2 = "37"

# byte1 = bytes.fromhex(byte1)
# byte2 = bytes.fromhex(byte2)


# Function to send two bytes to the serial port and print the response
def connect_to_serial(port, baudrate):
    try:     
        # Open the serial port
        ser = serial.Serial(port, baudrate, timeout=10)             
        # Send the two bytes to the serial port
        # ser.write(byte1)
        # ser.write(byte2)
        # print(f"Sent: {byte1.hex().upper()} {byte2.hex().upper()}")

        # # Give the device some time to process the command
        time.sleep(1)

        # Read the response from the serial port
        response = ser.read(ser.in_waiting or 1)  # Read all available bytes
        # while ser.in_waiting > 
        # response = ser.read(ser.in_waiting)
        response_hex = response.hex().upper()  # Convert the response to a hex string
        # byte_1 = bin(response[0])[2:].zfill(8)
        # byte_2 = bin(response[1])[2:].zfill(8)

        # response data
        # ERR = byte_1[7]
        # NP = byte_1[6]
        # WRN = byte_1[5]
        # CC1 = byte_1[4]

        
        print (f"received: {response_hex}")



    except serial.SerialException as e:
        print(f"Error: {e}")

# Send the bytes and print the response
while True:
    connect_to_serial(port, baudrate)