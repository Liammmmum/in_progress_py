class packet_data:
    
    def twos_complement_to_decimal(self, binary_str):
        n = len(binary_str)
        
        # Check if the number is negative
        if binary_str[0] == '1':
            # Invert all bits
            inverted_bits = ''.join('1' if bit == '0' else '0' for bit in binary_str)
            # Convert inverted binary to decimal and add 1
            decimal = int(inverted_bits, 2) + 1
            # Make it negative
            decimal = -decimal
        else:
            # Convert directly to decimal
            decimal = int(binary_str, 2)

        return decimal


    def __init__(self, indata):

        self.magic = hex(indata[1]) +','+ hex(indata[0])
        self.packet_type = chr(indata[2]) + chr(indata[3])
        self.packet_size = indata[7]*(256**3)+indata[6]*(256**2)+indata[5]*256+indata[4]
        self.header_size = indata[9]*256+indata[8]
        self.scan_number = indata[11]*256+indata[10]
        self.packet_number = indata[13] * 256 + indata[12]
        self.layer_index = indata[15] * 256 + indata[14]
        self.layer_inclination = (self.twos_complement_to_decimal(bin(indata[19]*(256**3)+indata[18]*(256**2)+indata[17]*256+indata[16])[2:].zfill(32))/10000)
        self.timestamp_raw = (indata[27]*(256**7)+indata[26]*(256**6)+indata[25]*(256**5)+indata[24]*(256**4)+indata[23]*(256**3)+indata[22]*(256**2)+indata[21]*256+indata[20])
        self.status_flags = indata[39]*(256**3)+indata[38]*(256**2)+indata[37]*256+indata[36]
        self.scan_frequency =  (indata[43] * (256**3)+indata[42] * (256**2)+ indata[41] * (256) + indata[40])/1000
        self.num_points_scan = indata[45] * 256 + indata[44]
        self.num_points_packet = indata[47] * 256 + indata[46]
        self.first_index = indata[49] * 256 + indata[48]
        self.first_angle = (self.twos_complement_to_decimal(bin(indata[53]*(256**3)+indata[52]*(256**2)+indata[51]*256+indata[50])[2:].zfill(32))/10000)
        self.angular_increment = ((indata[57]*(256**3)+indata[56]*(256**2)+indata[55]*256+indata[54])/10000)
        self.header_padding = indata[83] * 256 + indata[82]
        self.scan_point_data_bin = []
        self.scan_point_data = []
        self.distance_array = []
        self.amplitude_array = []
        for i in range(self.header_size,self.packet_size,4):
            self.distance_array.append(((indata[i+3]*(256**3)+indata[i+2]*(256**2)+indata[i+1]*256+indata[i])& 1048575))
            self.amplitude_array.append((((indata[i+3]*(256**3)+indata[i+2]*(256**2)+indata[i+1]*256+indata[i]))>>20))


