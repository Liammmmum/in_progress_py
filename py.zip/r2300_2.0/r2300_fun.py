import time
import json
import requests
import array as arr
import math
import numpy as np
import socket
import keyboard
import pyautogui
from r2300_class import packet_data

# define function to create_file
def save_ip(sensor_ip_address, pc_ip_address):
    file = open('network.dat', 'w')
    file.write(str(sensor_ip_address) + '\n' + str(pc_ip_address) + '\n')
    file.close()
    print('network setup:' + '\n' + 'sensor_ip_address:'+ sensor_ip_address + '\n' + 'pc_ip_address:' + pc_ip_address + '\n')

def send_request(url):
    try:
        r = requests.get(url, timeout=3)
        print(r.text)
    except:
        print ('error: no connection')
        return

def request_handle(url):
    try:
        r = requests.get(url, timeout=3)
        data = r.json()
        handle =data['handle']
        file = open('handle.dat', 'w')
        file.write(handle)
        file.close()
        print(r.text)
    except:
        print ('error: no connection')
        return

def read_ip():
    file = open('network.dat', 'r')
    content = file.read().splitlines()
    file.close()
    # print('network setup:' + '\n' + 'sensor_ip_address:'+ content[0] + '\n' + 'pc_ip_address:' + content[1] + '\n')
    return (content)

def check_ip():
    print('network setup:' + '\n' + 'sensor_ip_address:'+ read_ip()[0] + '\n' + 'pc_ip_address:' + read_ip()[1] + '\n')

def read_handle():
    file = open('Handle.dat', 'r')
    content = file.read()
    file.close()
    return (content)



def socket_connect(pc_ip_address):

    HOST = pc_ip_address
    PORT = 6464
    
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(5)
    try: 
        s.bind((HOST, PORT))
            # print('server start at: %s:%s' % (HOST, PORT))
        indata, adder = s.recvfrom(65536)
        scan_data = packet_data(indata)
        indata_1, adder_1 = s.recvfrom(65536)
        print('recvfrom ' + str(adder))
        
        while True:               
            while packet_data(indata_1).scan_number == scan_data.scan_number:
                scan_data.distance_array += (packet_data(indata_1).distance_array)
                scan_data.amplitude_array += (packet_data(indata_1).amplitude_array)
                indata_1, adder_1 = s.recvfrom(65536)             
            else:
                applications(scan_data)
                scan_data = packet_data(indata_1)
                indata_1, adder_1 = s.recvfrom(65536)
            
    except Exception as e:
        print (f'{e}')

    except:           
            s.close()
            print (f'socket closed')

# http commands
def http_commands (command):
    url = 'http://'+ read_ip()[0] + '/cmd/' + command
    return url

def raw_data_print (scan_data):
    
    print('magic:' + scan_data.magic)
    print('packet_type:' + scan_data.packet_type)
    print('packet_size:' + str(scan_data.packet_size)) 
    print('header_size:' + str(scan_data.header_size)) 
    print('scan_number:' + str(scan_data.scan_number)) 
    print('packet_number:' + str(scan_data.packet_number)) 
    print('layer_index:' + str(scan_data.layer_index)) 
    print('layer_inclination:' + str(scan_data.layer_inclination))
    print('timestamp_raw:' + str(scan_data.timestamp_raw))
    print('status_flags:' + str(scan_data.status_flags))
    print('scan_frequency:' + str(scan_data.scan_frequency))
    print('num_points_scan:' + str(scan_data.num_points_scan))
    print('num_points_packet:' + str(scan_data.num_points_packet))
    print('first_index:' + str(scan_data.first_index))
    print('first_angle:' + str(scan_data.first_angle))
    print('angular_increment:' + str(scan_data.angular_increment))
    print('header_padding:' + str(scan_data.header_padding))
    print('distance:' + str(scan_data.distance_array))
    print('amplitude:' + str(scan_data.amplitude_array))

def min_amplitude(scan_data):
    print(f'min. amplitude: {min(scan_data.amplitude_array)}')
    print(f'number of points scanned: {len(scan_data.amplitude_array)}')

def min_distance(scan_data):
    print(f'min. distance: {min(scan_data.distance_array)}')
    print(f'number of points scanned: {len(scan_data.distance_array)}')

def dir_control(scan_data):
    if min(scan_data.distance_array[0:20]) < 1000:
        keyboard.write('right')
        keyboard.press_and_release('right')
        print(f'turn right: {min(scan_data.distance_array[0:20])}')
    else:
        keyboard.write('left')
        keyboard.press_and_release('left')
        print(f'turn left: {min(scan_data.distance_array[0:20])}')
    # time.sleep(0.5)

def applications(scan_data):
    # raw_data_print(scan_data)
    # min_amplitude (scan_data)
    # min_distance (scan_data)
    dir_control(scan_data)

    
